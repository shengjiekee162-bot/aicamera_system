# AI Camera POS System

A beginner-friendly mobile POS built with PHP 8, MySQL, Bootstrap 5, vanilla JavaScript, and Google Gemini. Gemini identifies catalog products and quantities from a photo; all trusted product names, SKUs, prices, and stock values come from MySQL.

## Setup with XAMPP

1. Put this folder at `C:\xampp\htdocs\ai_system`.
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin at `http://localhost/phpmyadmin`.
4. Use **Import** to import `database.sql`.
5. If your MySQL username/password differs from XAMPP defaults, edit `config/database.php`.
6. Open `http://localhost/ai_system/`.

Default administrator login:

- Username: `admin`
- Password: `Admin@123`

Change this password from **Users** after the first login.

## Gemini configuration

1. Create a Gemini API key in Google AI Studio.
2. Log in as admin and open **Settings**.
3. Enter one shared Gemini API key, configure up to five model slots, and select the current active model.
   The API URL supports a `{model}` placeholder, for example `https://generativelanguage.googleapis.com/v1/models/{model}:generateContent`.
4. Save, then click **Test AI Fallback**. The keys are stored in the database and are never sent back to the browser after saving.

During detection, slots are tried in priority order. If the active model returns a quota/rate-limit response (including HTTP 429), an unavailable-model response, or a temporary Gemini service error, the request automatically continues with the next configured slot.

The model names in Settings follow the requested configuration. If Google does not provide one of those model IDs for your account, the test will show the API error; choose an available configured model ID.

## Test the camera POS

1. Add products with clear names, unique SKUs, stock, prices, and optionally reference images.
2. Create a cashier account in **Users**, or use the admin account to open POS.
3. On a phone, browse to the HTTPS URL for this app. Camera access normally requires HTTPS (localhost is allowed on the same computer).
4. Tap **Open Camera**, photograph one or more products, and tap **Detect Products**.
5. Confirm quantities. Unknown products appear as “Product not found” and can be searched and added manually.
6. Choose a payment method, enter cash received if needed, and confirm checkout.
7. The server re-reads current prices and locks stock inside a transaction before saving the order. Print the generated receipt.

## Deployment notes

- PHP extensions required: PDO MySQL, cURL, Fileinfo, JSON, and OpenSSL.
- Make `uploads/products` writable by the web server.
- Use HTTPS for mobile camera access.
- Keep `display_errors` off in production and enable PHP error logging.
- Back up the database regularly. Never commit or paste a real Gemini key into source code.
